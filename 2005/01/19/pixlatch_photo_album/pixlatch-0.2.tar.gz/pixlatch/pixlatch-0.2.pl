#!/usr/bin/perl

use Image::Magick;

$PIX = ".pixlatch";

open(TEMPLATE, "template.html") or die "Can't open template: $!";
while(<TEMPLATE>) { $template .= $_ }
close(TEMPLATE);

opendir(ROOT,"./");
$root = `pwd`; chomp($root); 

foreach(readdir(ROOT)) {
   if($_ =~ /^\./) { next } #Skip hidden files / directories
   if(chdir $_) {
      push(@directories,$_);
      chdir($root)
   }
}

@directories = sort(@directories);
mkdir($PIX);

foreach(<@directories>) {
   undef($last);
   $page = "<a href=\"../../\">Back to Main Index</a><hr>\n";
   $rdir = "$root/$_";
   $rrel = "$_";
   $wdir = "$root/$PIX/$_";
   $wrel = "$PIX/$_";
   mkdir($wdir);

   opendir(RDIR,$rdir) or die "Cannot open $rdir: $!";
   print "Opened $rdir\n";
   @pics = sort( grep { /.jpg$/i } readdir(RDIR) );
   $thumb = $pics[0];
   $thumb =~ s/\....$//;
   $rtind .= "<p><a href=\"$wrel/\"><img src=\"$wrel/$thumb-10.jpg\"><br>\n$_</a></p>\n";
   closedir(RDIR);

   opendir(WDIR,$wdir) or die "Cannot access $wdir: $!";
   while(<@pics>) {

      $file = $_;
      $_ =~ s/(.*)\..../$1/;

      $page .= "<a href=\"$_-10.html\"><img src=\"$_-0.jpg\"></a>";

      print "Processing $file";
      # Read in the image
      $model = Image::Magick->new();
      $x = $model->ReadImage("$rdir/$file");
      warn "$x" if "$x";

      foreach $y (10,25,50) {
         # Scale the image
         $example = $model->Clone();
         $example->Label('Scale');
         $example->Scale("$y%");

         # Write out the image
         $example->Write("$wdir/$_-$y.jpg");
         if($y eq "50") { print ".\n" } else { print "." }
      }

      $example = $model->Clone();
      $example->Label('Scale');
      $example->Scale('120');
      $example->Write("$wdir/$_-0.jpg");
   }

   open(OUTPUT,">$wdir/index.html");
   print OUTPUT "<html><body>";
   print OUTPUT <<EOF;
   <style type="text/css">
   img {
      margin: 2.5px;
   }
   </style>
EOF
   print OUTPUT $page;
   print OUTPUT "</body></html>";
   close(OUTPUT);

   while($elem = shift(@pics)){
      $name = $elem;
      $name =~ s/(.*)\..../$1/; # Strip extension

      $next = $pics[0];
      $next =~ s/(.*)\..../$1/; # Strip extension

      foreach(10,25,50) {
         open(SUB,">$wdir/$name-$_.html") or die "Can't write to $wdir/$name-$_.html: $!";
         print SUB " <html><body><center><br><a href=\"../../$rrel/$elem\"><img src=\"$name-$_.jpg\"></a><br>";
         print SUB "<a href=\"index.html\">^</a><br>\n";
         if($last) { print SUB "<a href=\"$last-$_.html\">&lt;&lt;</a> " }
         print SUB "<a href=\"$name-10.html\">S</a>\n";
         print SUB "<a href=\"$name-25.html\">M</a>\n";
         print SUB "<a href=\"$name-50.html\">L</a>\n";
         if($next) { print SUB "<a href=\"$next-$_.html\">&gt;&gt;</a>\n" }
         print SUB "</body></html>";
         close(SUB);
      }
      $last = $name;
      chdir($root);
   }
}

open(RTIND,">$root/index.html") or die "Can't write to $root/index.html: $!";
$output = $template;
$output =~ s/<!--Main Viewport-->/$rtind/;
print RTIND "$output";
close(RTIND);














